Create table EMPLOYEEPRJ (
	Fname varchar (50) NOT NULL ,
	Lname varchar (50) NOT NULL ,
	Ssn int NOT NULL ,
	Pname varchar(50) NOT NULL ,
	Pnumber int  NOT NULL ,
	Dname varchar(50) NOT NULL , 
	Dnumber int  NOT NULL , 
)

insert into EMPLOYEEPRJ
select emp.Fname , emp.Lname , emp.Ssn  , pro.Pname , pro.Pnumber , dep.Dname , dep.Dnumber
from EMPLOYEE  as emp inner join DEPARTMENT as dep on emp.Dno = dep.Dnumber
     inner join PROJECT as pro on dep.Dnumber = pro.Dnum

select *
from EMPLOYEEPRJ
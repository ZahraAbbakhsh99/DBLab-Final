Select distinct top(5) Fname , Lname , Ssn , Salary
from EMPLOYEE
order by Salary ASC 
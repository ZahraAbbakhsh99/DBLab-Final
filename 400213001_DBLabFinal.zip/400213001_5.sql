-- Alter DEPARTMENT table(
--	Max_Prj_Num int not null ,
--)

CREATE TRIGGER t1
on DEPARTMENT
after UPDATE , insert 
as
	declare @numpro int

	select @numpro = @@ROWCOUNT 
	from  DEPARTMENT AS dep left outer join PROJECT as pro on dep.Dnumber = pro.Dnum
	
	declare @Maxnumpro int

	select @Maxnumpro = Max_Prj_Num
    from  DEPARTMENT

	IF (@numpro) >  (@Maxnumpro)
	BEGIN
		PRINT 'You cannot change it'
		ROLLBACK
	END

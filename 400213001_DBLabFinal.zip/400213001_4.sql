Create procedure p
as 
	declare @temp Table (
	Dname varchar(50) not null ,
	Dnumber int not null , 
	Dlocation varchar (100) not null ,
	numberofemps int ,
	sumOfSalary money 
	);

	insert into @temp 
	select dep.Dname as [depName] ,dep.Dnumber as [depNumber] , deplo.Dlocation as [depLocation],
			count(emp.Ssn) as [numberofemps] , sum(emp.Salary) as [sumOfSalary]
	from DEPARTMENT as dep left outer join EMPLOYEE as emp on emp.Dno = dep.Dnumber
	                left outer join DEPT_LOCATIONS as deplo on dep.Dnumber = deplo.Dnumber
	group by dep.Dname ,dep.Dnumber , deplo.Dlocation 
	
	select * 
	from @temp 


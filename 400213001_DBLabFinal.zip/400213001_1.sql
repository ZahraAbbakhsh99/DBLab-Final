CREATE TABLE DEPARTMENT (
	Dname varchar(50) NOT NULL , 
	Dnumber int identity (1,1) primary key NOT NULL , 
	Mgr_Ssn int ,
	Mgr_start_date date NOT NULL  ,
	Max_Prj_Num int NOT NULL ,
)

CREATE TABLE EMPLOYEE (
	Fname varchar (50) NOT NULL ,
	Minit varchar(50) NOT NULL ,
	Lname varchar (50) NOT NULL ,
	Ssn int identity (1,1) primary key NOT NULL ,
	Bdate date NOT NULL ,
	EAddress varchar (100) NOT NULL , 
	Sex varchar (50) NOT NULL ,
	Salary money NOT NULL ,
	Super_Ssn int ,
	Dno int NOT NULL ,

	foreign key (Super_Ssn) references DEPARTMENT(Dnumber) ,
	foreign key (Dno) references EMPLOYEE(Ssn) ,
)

CREATE TABLE DEPT_LOCATIONS (
	Dnumber int NOT NULL primary key  , 
	Dlocation varchar (100) NOT NULL  , 

	foreign key (Dnumber) references DEPARTMENT(Dnumber)
)

CREATE TABLE PROJECT(
	Pname varchar(50) NOT NULL ,
	Pnumber int identity (1,1) primary key NOT NULL ,
	Plocation varchar(100) NOT NULL , 
	Dnum int NOT NULL , 

	FOREIGN KEY (Dnum) references DEPARTMENT(Dnumber) 
)



insert into DEPARTMENT(Dname , Mgr_Ssn , Mgr_start_date , Max_Prj_Num)
values ('managment' ,1 , '2021' , 35)

insert into DEPARTMENT(Dname , Mgr_Ssn , Mgr_start_date , Max_Prj_Num)
values ('IT' , 2 , '2022' , 15)

insert into DEPARTMENT(Dname , Mgr_Ssn , Mgr_start_date , Max_Prj_Num)
values ('Support' , 3 , '2022' , 10)


insert into EMPLOYEE(Fname , Minit, Lname , Bdate , EAddress , Sex , Salary , Super_Ssn , Dno)
values ('Zahra' , 'a' ,'Abbakhsh' , '2003' , 'behbahan' , 'fmale' , 3400000 , null , 1 )

insert into EMPLOYEE(Fname , Minit, Lname , Bdate , EAddress , Sex , Salary , Super_Ssn , Dno)
values ('Mahsa' , 'b' ,'Alizadeh' , '2003' , 'kerman' , 'fmale' , 1200000 , null , 2 )

insert into EMPLOYEE(Fname , Minit, Lname , Bdate , EAddress , Sex , Salary , Super_Ssn , Dno)
values ('Reza' , 'c' ,'AryanManesh' , '2002' , 'shiraz' , 'male' , 1900000 , null , 3)

insert into EMPLOYEE(Fname , Minit, Lname , Bdate , EAddress , Sex , Salary , Super_Ssn , Dno)
values ('Ali' , 'd' ,'Saket' , '2003' , 'tehran' , 'male' , 1000000 , 3 , 3 )

insert into EMPLOYEE(Fname , Minit, Lname , Bdate , EAddress , Sex , Salary , Super_Ssn , Dno)
values ('Sara' , 'e' ,'Karimi' , '2002' , 'behbahan' , 'fmale' , 1500000 , 2,  2 )

insert into EMPLOYEE(Fname , Minit, Lname , Bdate , EAddress , Sex , Salary , Super_Ssn , Dno)
values ('Armin' , 'f' ,'Askari' , '2003' , 'behbahan' , 'male' , 2000000 , 4 , 3 )


insert into DEPT_LOCATIONS( Dnumber , Dlocation)
values (1 , 'Shiraz')

insert into DEPT_LOCATIONS( Dnumber , Dlocation)
values (2 , 'Tehren')

insert into DEPT_LOCATIONS( Dnumber , Dlocation)
values (3 , 'Mashhad')


insert into PROJECT(Pname , Plocation , Dnum)
values('managering' , 'Tehran' , 1)

insert into PROJECT(Pname , Plocation , Dnum)
values('payment' , 'Mashhad' , 3)

insert into PROJECT(Pname , Plocation , Dnum)
values('programming' , 'Shiraz' , 2)

